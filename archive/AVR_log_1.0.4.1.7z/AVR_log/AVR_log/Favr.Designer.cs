﻿namespace AVR_log
{
    partial class Favr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Favr));
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.P_rise = new System.Windows.Forms.NumericUpDown();
			this.kol_rise = new System.Windows.Forms.NumericUpDown();
			this.label32 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.cbTypeVL = new System.Windows.Forms.ComboBox();
			this.lbFilter = new System.Windows.Forms.Label();
			this.edFilter = new System.Windows.Forms.TextBox();
			this.button6 = new System.Windows.Forms.Button();
			this.lbSelectRes = new System.Windows.Forms.Label();
			this.t_otkl = new System.Windows.Forms.MaskedTextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.P_load = new System.Windows.Forms.NumericUpDown();
			this.label34 = new System.Windows.Forms.Label();
			this.TP = new System.Windows.Forms.NumericUpDown();
			this.SZO = new System.Windows.Forms.NumericUpDown();
			this.Population = new System.Windows.Forms.NumericUpDown();
			this.NP = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.cbP_load = new System.Windows.Forms.ComboBox();
			this.d_otkl = new System.Windows.Forms.DateTimePicker();
			this.label4 = new System.Windows.Forms.Label();
			this.cbFider = new System.Windows.Forms.ComboBox();
			this.cbRes = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.cbCompany = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.btnDotResultOsm = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.d_osm = new System.Windows.Forms.DateTimePicker();
			this.button3 = new System.Windows.Forms.Button();
			this.result_osm = new System.Windows.Forms.TextBox();
			this.label16 = new System.Windows.Forms.Label();
			this.tableMastersOsm = new System.Windows.Forms.TableLayoutPanel();
			this.telMasterOsm4 = new System.Windows.Forms.MaskedTextBox();
			this.dolMasterOsm4 = new System.Windows.Forms.TextBox();
			this.telMasterOsm3 = new System.Windows.Forms.MaskedTextBox();
			this.dolMasterOsm3 = new System.Windows.Forms.TextBox();
			this.telMasterOsm2 = new System.Windows.Forms.MaskedTextBox();
			this.dolMasterOsm2 = new System.Windows.Forms.TextBox();
			this.telMasterOsm1 = new System.Windows.Forms.MaskedTextBox();
			this.cbMasterOsm4 = new System.Windows.Forms.ComboBox();
			this.cbMasterOsm3 = new System.Windows.Forms.ComboBox();
			this.cbMasterOsm2 = new System.Windows.Forms.ComboBox();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.cbMasterOsm1 = new System.Windows.Forms.ComboBox();
			this.label13 = new System.Windows.Forms.Label();
			this.dolMasterOsm1 = new System.Windows.Forms.TextBox();
			this.kol_pers_osm = new System.Windows.Forms.NumericUpDown();
			this.label12 = new System.Windows.Forms.Label();
			this.kol_br_osm = new System.Windows.Forms.NumericUpDown();
			this.label11 = new System.Windows.Forms.Label();
			this.t_osm = new System.Windows.Forms.MaskedTextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.button7 = new System.Windows.Forms.Button();
			this.cbBasaAvr = new System.Windows.Forms.ComboBox();
			this.label25 = new System.Windows.Forms.Label();
			this.t_plan_okon = new System.Windows.Forms.MaskedTextBox();
			this.label29 = new System.Windows.Forms.Label();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.Kran = new System.Windows.Forms.NumericUpDown();
			this.Label30 = new System.Windows.Forms.Label();
			this.BKM = new System.Windows.Forms.NumericUpDown();
			this.label24 = new System.Windows.Forms.Label();
			this.AGP = new System.Windows.Forms.NumericUpDown();
			this.label23 = new System.Windows.Forms.Label();
			this.cbPrinadl_br = new System.Windows.Forms.ComboBox();
			this.label22 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.telMasterAvr = new System.Windows.Forms.MaskedTextBox();
			this.dolMasterAvr = new System.Windows.Forms.TextBox();
			this.cbMasterAvr = new System.Windows.Forms.ComboBox();
			this.kol_pers_avr = new System.Windows.Forms.NumericUpDown();
			this.label19 = new System.Windows.Forms.Label();
			this.kol_br_avr = new System.Windows.Forms.NumericUpDown();
			this.label20 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.t_vkl_vl = new System.Windows.Forms.MaskedTextBox();
			this.d_vkl_vl = new System.Windows.Forms.DateTimePicker();
			this.label18 = new System.Windows.Forms.Label();
			this.button4 = new System.Windows.Forms.Button();
			this.t_avr = new System.Windows.Forms.MaskedTextBox();
			this.d_avr = new System.Windows.Forms.DateTimePicker();
			this.label17 = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.btnDotObemRabot = new System.Windows.Forms.Button();
			this.cbEndOfWork = new System.Windows.Forms.CheckBox();
			this.btn_set_t_vkl_potr = new System.Windows.Forms.Button();
			this.t_vkl_potr = new System.Windows.Forms.MaskedTextBox();
			this.d_vkl_potr = new System.Windows.Forms.DateTimePicker();
			this.cbPerem_br = new System.Windows.Forms.ComboBox();
			this.label27 = new System.Windows.Forms.Label();
			this.obem_rabot = new System.Windows.Forms.TextBox();
			this.label26 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.cbUser = new System.Windows.Forms.ComboBox();
			this.label9 = new System.Windows.Forms.Label();
			this.btn_save = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.contextMenuResult_Osm = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
			this.contextMenuObem_Rabot = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.заменаПроводаВПролетахОпорToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.заменаОпорыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
			this.Hint1 = new System.Windows.Forms.ToolTip(this.components);
			this.groupBox1.SuspendLayout();
			this.groupBox7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.P_rise)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_rise)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.P_load)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.TP)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SZO)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.Population)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NP)).BeginInit();
			this.groupBox3.SuspendLayout();
			this.tableMastersOsm.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.kol_pers_osm)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_br_osm)).BeginInit();
			this.groupBox4.SuspendLayout();
			this.groupBox6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.Kran)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BKM)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.AGP)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_pers_avr)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_br_avr)).BeginInit();
			this.groupBox5.SuspendLayout();
			this.panel1.SuspendLayout();
			this.contextMenuResult_Osm.SuspendLayout();
			this.contextMenuObem_Rabot.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
			this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.groupBox1.Controls.Add(this.groupBox7);
			this.groupBox1.Controls.Add(this.label31);
			this.groupBox1.Controls.Add(this.cbTypeVL);
			this.groupBox1.Controls.Add(this.lbFilter);
			this.groupBox1.Controls.Add(this.edFilter);
			this.groupBox1.Controls.Add(this.button6);
			this.groupBox1.Controls.Add(this.lbSelectRes);
			this.groupBox1.Controls.Add(this.t_otkl);
			this.groupBox1.Controls.Add(this.groupBox2);
			this.groupBox1.Controls.Add(this.d_otkl);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.cbFider);
			this.groupBox1.Controls.Add(this.cbRes);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.cbCompany);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.groupBox1.Location = new System.Drawing.Point(3, 3);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 5);
			this.groupBox1.Size = new System.Drawing.Size(713, 160);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Данные по фидеру";
			this.groupBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// groupBox7
			// 
			this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(255)))));
			this.groupBox7.Controls.Add(this.P_rise);
			this.groupBox7.Controls.Add(this.kol_rise);
			this.groupBox7.Controls.Add(this.label32);
			this.groupBox7.Controls.Add(this.label33);
			this.groupBox7.Location = new System.Drawing.Point(541, 100);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(165, 55);
			this.groupBox7.TabIndex = 31;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Задействованные РИСЭ";
			this.groupBox7.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// P_rise
			// 
			this.P_rise.DecimalPlaces = 3;
			this.P_rise.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.P_rise.Location = new System.Drawing.Point(76, 31);
			this.P_rise.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.P_rise.Name = "P_rise";
			this.P_rise.Size = new System.Drawing.Size(76, 20);
			this.P_rise.TabIndex = 8;
			// 
			// kol_rise
			// 
			this.kol_rise.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.kol_rise.Location = new System.Drawing.Point(76, 14);
			this.kol_rise.Name = "kol_rise";
			this.kol_rise.Size = new System.Drawing.Size(76, 20);
			this.kol_rise.TabIndex = 7;
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label32.ForeColor = System.Drawing.Color.Black;
			this.label32.Location = new System.Drawing.Point(5, 35);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(46, 13);
			this.label32.TabIndex = 10;
			this.label32.Text = "P∑, кВт";
			this.Hint1.SetToolTip(this.label32, "Суммарная мощность");
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label33.ForeColor = System.Drawing.Color.Black;
			this.label33.Location = new System.Drawing.Point(5, 16);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(66, 13);
			this.label33.TabIndex = 9;
			this.label33.Text = "Количество";
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label31.Location = new System.Drawing.Point(7, 79);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(79, 13);
			this.label31.TabIndex = 30;
			this.label31.Text = "Энергообъект";
			// 
			// cbTypeVL
			// 
			this.cbTypeVL.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbTypeVL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbTypeVL.FormattingEnabled = true;
			this.cbTypeVL.Location = new System.Drawing.Point(87, 76);
			this.cbTypeVL.Name = "cbTypeVL";
			this.cbTypeVL.Size = new System.Drawing.Size(78, 21);
			this.cbTypeVL.TabIndex = 29;
			this.cbTypeVL.SelectedIndexChanged += new System.EventHandler(this.CbTypeVL_SelectedIndexChanged);
			// 
			// lbFilter
			// 
			this.lbFilter.AutoSize = true;
			this.lbFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.lbFilter.Location = new System.Drawing.Point(133, 56);
			this.lbFilter.Name = "lbFilter";
			this.lbFilter.Size = new System.Drawing.Size(50, 13);
			this.lbFilter.TabIndex = 28;
			this.lbFilter.Text = "Фильтр:";
			this.lbFilter.Visible = false;
			// 
			// edFilter
			// 
			this.edFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.edFilter.Location = new System.Drawing.Point(193, 53);
			this.edFilter.Name = "edFilter";
			this.edFilter.Size = new System.Drawing.Size(305, 20);
			this.edFilter.TabIndex = 27;
			this.edFilter.Visible = false;
			// 
			// button6
			// 
			this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.button6.Location = new System.Drawing.Point(659, 42);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(15, 20);
			this.button6.TabIndex = 26;
			this.button6.TabStop = false;
			this.button6.Text = "<";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.Button6_Click);
			// 
			// lbSelectRes
			// 
			this.lbSelectRes.AutoSize = true;
			this.lbSelectRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.lbSelectRes.ForeColor = System.Drawing.Color.Maroon;
			this.lbSelectRes.Location = new System.Drawing.Point(284, 40);
			this.lbSelectRes.Name = "lbSelectRes";
			this.lbSelectRes.Size = new System.Drawing.Size(106, 13);
			this.lbSelectRes.TabIndex = 17;
			this.lbSelectRes.Text = "* РЭС не выбран";
			this.lbSelectRes.Visible = false;
			// 
			// t_otkl
			// 
			this.t_otkl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_otkl.Location = new System.Drawing.Point(611, 42);
			this.t_otkl.Mask = "00:00";
			this.t_otkl.Name = "t_otkl";
			this.t_otkl.PromptChar = ' ';
			this.t_otkl.Size = new System.Drawing.Size(42, 18);
			this.t_otkl.TabIndex = 4;
			this.t_otkl.ValidatingType = typeof(System.DateTime);
			this.t_otkl.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
			this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.groupBox2.Controls.Add(this.P_load);
			this.groupBox2.Controls.Add(this.label34);
			this.groupBox2.Controls.Add(this.TP);
			this.groupBox2.Controls.Add(this.SZO);
			this.groupBox2.Controls.Add(this.Population);
			this.groupBox2.Controls.Add(this.NP);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.cbP_load);
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox2.Location = new System.Drawing.Point(3, 100);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(536, 55);
			this.groupBox2.TabIndex = 16;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Количество отключенных";
			this.groupBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// P_load
			// 
			this.P_load.DecimalPlaces = 3;
			this.P_load.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.P_load.Location = new System.Drawing.Point(436, 14);
			this.P_load.Maximum = new decimal(new int[] {
            999,
            0,
            0,
            0});
			this.P_load.Name = "P_load";
			this.P_load.Size = new System.Drawing.Size(76, 20);
			this.P_load.TabIndex = 10;
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label34.ForeColor = System.Drawing.Color.Black;
			this.label34.Location = new System.Drawing.Point(351, 16);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(82, 13);
			this.label34.TabIndex = 11;
			this.label34.Text = "Нагрузка, МВт";
			// 
			// TP
			// 
			this.TP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.TP.Location = new System.Drawing.Point(257, 31);
			this.TP.Name = "TP";
			this.TP.Size = new System.Drawing.Size(92, 20);
			this.TP.TabIndex = 3;
			// 
			// SZO
			// 
			this.SZO.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.SZO.Location = new System.Drawing.Point(257, 14);
			this.SZO.Name = "SZO";
			this.SZO.Size = new System.Drawing.Size(92, 20);
			this.SZO.TabIndex = 2;
			// 
			// Population
			// 
			this.Population.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.Population.Location = new System.Drawing.Point(127, 31);
			this.Population.Name = "Population";
			this.Population.Size = new System.Drawing.Size(92, 20);
			this.Population.TabIndex = 1;
			// 
			// NP
			// 
			this.NP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.NP.Location = new System.Drawing.Point(127, 14);
			this.NP.Name = "NP";
			this.NP.Size = new System.Drawing.Size(92, 20);
			this.NP.TabIndex = 0;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label7.ForeColor = System.Drawing.Color.Black;
			this.label7.Location = new System.Drawing.Point(227, 35);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(22, 13);
			this.label7.TabIndex = 6;
			this.label7.Text = "ТП";
			this.Hint1.SetToolTip(this.label7, "Трансформаторных подстанций");
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label8.ForeColor = System.Drawing.Color.Black;
			this.label8.Location = new System.Drawing.Point(227, 16);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(29, 13);
			this.label8.TabIndex = 4;
			this.label8.Text = "СЗО";
			this.Hint1.SetToolTip(this.label8, "Социально значимых объектов");
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label6.ForeColor = System.Drawing.Color.Black;
			this.label6.Location = new System.Drawing.Point(9, 33);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(63, 13);
			this.label6.TabIndex = 2;
			this.label6.Text = "Населения";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label5.ForeColor = System.Drawing.Color.Black;
			this.label5.Location = new System.Drawing.Point(8, 16);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(113, 13);
			this.label5.TabIndex = 0;
			this.label5.Text = "Населённых пунктов";
			// 
			// cbP_load
			// 
			this.cbP_load.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbP_load.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbP_load.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbP_load.Location = new System.Drawing.Point(436, 13);
			this.cbP_load.Margin = new System.Windows.Forms.Padding(0);
			this.cbP_load.MaxDropDownItems = 2;
			this.cbP_load.Name = "cbP_load";
			this.cbP_load.Size = new System.Drawing.Size(96, 21);
			this.cbP_load.TabIndex = 12;
			this.cbP_load.Visible = false;
			this.cbP_load.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.CbP_load_DrawItem);
			this.cbP_load.SelectedIndexChanged += new System.EventHandler(this.CbP_load_SelectedIndexChanged);
			// 
			// d_otkl
			// 
			this.d_otkl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.d_otkl.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.d_otkl.Location = new System.Drawing.Point(611, 20);
			this.d_otkl.Name = "d_otkl";
			this.d_otkl.Size = new System.Drawing.Size(92, 18);
			this.d_otkl.TabIndex = 3;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label4.Location = new System.Drawing.Point(517, 20);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(93, 42);
			this.label4.TabIndex = 13;
			this.label4.Text = "Дата и время отключение ВЛ";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cbFider
			// 
			this.cbFider.DisplayMember = "0";
			this.cbFider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFider.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbFider.FormattingEnabled = true;
			this.cbFider.Location = new System.Drawing.Point(168, 76);
			this.cbFider.Name = "cbFider";
			this.cbFider.Size = new System.Drawing.Size(538, 21);
			this.cbFider.TabIndex = 7;
			this.cbFider.SelectionChangeCommitted += new System.EventHandler(this.CbFider_SelectionChangeCommitted);
			this.cbFider.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CbFider_KeyPress);
			this.cbFider.Leave += new System.EventHandler(this.CbFider_Leave);
			// 
			// cbRes
			// 
			this.cbRes.DisplayMember = "0";
			this.cbRes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbRes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbRes.FormattingEnabled = true;
			this.cbRes.Location = new System.Drawing.Point(287, 19);
			this.cbRes.Name = "cbRes";
			this.cbRes.Size = new System.Drawing.Size(211, 21);
			this.cbRes.TabIndex = 2;
			this.cbRes.SelectionChangeCommitted += new System.EventHandler(this.CbRes_SelectionChangeCommitted);
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label2.Location = new System.Drawing.Point(258, 22);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(28, 13);
			this.label2.TabIndex = 10;
			this.label2.Text = "РЭС";
			// 
			// cbCompany
			// 
			this.cbCompany.DisplayMember = "0";
			this.cbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbCompany.FormattingEnabled = true;
			this.cbCompany.Location = new System.Drawing.Point(36, 19);
			this.cbCompany.Name = "cbCompany";
			this.cbCompany.Size = new System.Drawing.Size(211, 21);
			this.cbCompany.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label1.Location = new System.Drawing.Point(7, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(23, 13);
			this.label1.TabIndex = 8;
			this.label1.Text = "ПО";
			// 
			// groupBox3
			// 
			this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(235)))));
			this.groupBox3.Controls.Add(this.button1);
			this.groupBox3.Controls.Add(this.btnDotResultOsm);
			this.groupBox3.Controls.Add(this.label3);
			this.groupBox3.Controls.Add(this.d_osm);
			this.groupBox3.Controls.Add(this.button3);
			this.groupBox3.Controls.Add(this.result_osm);
			this.groupBox3.Controls.Add(this.label16);
			this.groupBox3.Controls.Add(this.tableMastersOsm);
			this.groupBox3.Controls.Add(this.kol_pers_osm);
			this.groupBox3.Controls.Add(this.label12);
			this.groupBox3.Controls.Add(this.kol_br_osm);
			this.groupBox3.Controls.Add(this.label11);
			this.groupBox3.Controls.Add(this.t_osm);
			this.groupBox3.Controls.Add(this.label10);
			this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox3.Location = new System.Drawing.Point(3, 163);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(713, 154);
			this.groupBox3.TabIndex = 1;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Проведение осмотра";
			this.groupBox3.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// button1
			// 
			this.button1.ImageIndex = 0;
			this.button1.ImageList = this.imageList1;
			this.button1.Location = new System.Drawing.Point(682, 31);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(24, 20);
			this.button1.TabIndex = 29;
			this.Hint1.SetToolTip(this.button1, "Добавить нового руководителя бригады");
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1_Click_1);
			// 
			// imageList1
			// 
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			this.imageList1.Images.SetKeyName(0, "ic_add_circle_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(1, "ic_remove_circle_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(2, "ic_create_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(3, "ic_grid_on_grey600_18dp.png");
			// 
			// btnDotResultOsm
			// 
			this.btnDotResultOsm.Cursor = System.Windows.Forms.Cursors.PanWest;
			this.btnDotResultOsm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.btnDotResultOsm.Location = new System.Drawing.Point(682, 129);
			this.btnDotResultOsm.Name = "btnDotResultOsm";
			this.btnDotResultOsm.Size = new System.Drawing.Size(16, 21);
			this.btnDotResultOsm.TabIndex = 28;
			this.btnDotResultOsm.Text = "Ш";
			this.btnDotResultOsm.UseVisualStyleBackColor = true;
			this.btnDotResultOsm.Click += new System.EventHandler(this.BtnDotResultOsm_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label3.Location = new System.Drawing.Point(46, 20);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(42, 13);
			this.label3.TabIndex = 27;
			this.label3.Text = "Дата и";
			// 
			// d_osm
			// 
			this.d_osm.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.d_osm.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.d_osm.Location = new System.Drawing.Point(94, 15);
			this.d_osm.Name = "d_osm";
			this.d_osm.Size = new System.Drawing.Size(92, 18);
			this.d_osm.TabIndex = 0;
			// 
			// button3
			// 
			this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.button3.Location = new System.Drawing.Point(139, 36);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(15, 20);
			this.button3.TabIndex = 25;
			this.button3.TabStop = false;
			this.button3.Text = "<";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.Button3_Click);
			// 
			// result_osm
			// 
			this.result_osm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.result_osm.Location = new System.Drawing.Point(168, 130);
			this.result_osm.MaxLength = 255;
			this.result_osm.Name = "result_osm";
			this.result_osm.Size = new System.Drawing.Size(514, 20);
			this.result_osm.TabIndex = 24;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label16.Location = new System.Drawing.Point(7, 133);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(158, 13);
			this.label16.TabIndex = 23;
			this.label16.Text = "Обнаруженные повреждения:";
			// 
			// tableMastersOsm
			// 
			this.tableMastersOsm.ColumnCount = 3;
			this.tableMastersOsm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 211F));
			this.tableMastersOsm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 163F));
			this.tableMastersOsm.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableMastersOsm.Controls.Add(this.telMasterOsm4, 2, 4);
			this.tableMastersOsm.Controls.Add(this.dolMasterOsm4, 1, 4);
			this.tableMastersOsm.Controls.Add(this.telMasterOsm3, 2, 3);
			this.tableMastersOsm.Controls.Add(this.dolMasterOsm3, 1, 3);
			this.tableMastersOsm.Controls.Add(this.telMasterOsm2, 2, 2);
			this.tableMastersOsm.Controls.Add(this.dolMasterOsm2, 1, 2);
			this.tableMastersOsm.Controls.Add(this.telMasterOsm1, 2, 1);
			this.tableMastersOsm.Controls.Add(this.cbMasterOsm4, 0, 4);
			this.tableMastersOsm.Controls.Add(this.cbMasterOsm3, 0, 3);
			this.tableMastersOsm.Controls.Add(this.cbMasterOsm2, 0, 2);
			this.tableMastersOsm.Controls.Add(this.label15, 2, 0);
			this.tableMastersOsm.Controls.Add(this.label14, 1, 0);
			this.tableMastersOsm.Controls.Add(this.cbMasterOsm1, 0, 1);
			this.tableMastersOsm.Controls.Add(this.label13, 0, 0);
			this.tableMastersOsm.Controls.Add(this.dolMasterOsm1, 1, 1);
			this.tableMastersOsm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.tableMastersOsm.Location = new System.Drawing.Point(190, 15);
			this.tableMastersOsm.Name = "tableMastersOsm";
			this.tableMastersOsm.RowCount = 5;
			this.tableMastersOsm.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableMastersOsm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
			this.tableMastersOsm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
			this.tableMastersOsm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
			this.tableMastersOsm.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
			this.tableMastersOsm.Size = new System.Drawing.Size(492, 111);
			this.tableMastersOsm.TabIndex = 22;
			// 
			// telMasterOsm4
			// 
			this.telMasterOsm4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.telMasterOsm4.Location = new System.Drawing.Point(377, 88);
			this.telMasterOsm4.Mask = "00000000000";
			this.telMasterOsm4.Name = "telMasterOsm4";
			this.telMasterOsm4.PromptChar = ' ';
			this.telMasterOsm4.ReadOnly = true;
			this.telMasterOsm4.Size = new System.Drawing.Size(112, 20);
			this.telMasterOsm4.TabIndex = 11;
			this.telMasterOsm4.Click += new System.EventHandler(this.ClicOnTlfVield);
			// 
			// dolMasterOsm4
			// 
			this.dolMasterOsm4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dolMasterOsm4.Location = new System.Drawing.Point(214, 88);
			this.dolMasterOsm4.Name = "dolMasterOsm4";
			this.dolMasterOsm4.ReadOnly = true;
			this.dolMasterOsm4.Size = new System.Drawing.Size(157, 20);
			this.dolMasterOsm4.TabIndex = 10;
			// 
			// telMasterOsm3
			// 
			this.telMasterOsm3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.telMasterOsm3.Location = new System.Drawing.Point(377, 64);
			this.telMasterOsm3.Mask = "00000000000";
			this.telMasterOsm3.Name = "telMasterOsm3";
			this.telMasterOsm3.PromptChar = ' ';
			this.telMasterOsm3.ReadOnly = true;
			this.telMasterOsm3.Size = new System.Drawing.Size(112, 20);
			this.telMasterOsm3.TabIndex = 8;
			this.telMasterOsm3.Click += new System.EventHandler(this.ClicOnTlfVield);
			// 
			// dolMasterOsm3
			// 
			this.dolMasterOsm3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dolMasterOsm3.Location = new System.Drawing.Point(214, 64);
			this.dolMasterOsm3.Name = "dolMasterOsm3";
			this.dolMasterOsm3.ReadOnly = true;
			this.dolMasterOsm3.Size = new System.Drawing.Size(157, 20);
			this.dolMasterOsm3.TabIndex = 7;
			// 
			// telMasterOsm2
			// 
			this.telMasterOsm2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.telMasterOsm2.Location = new System.Drawing.Point(377, 40);
			this.telMasterOsm2.Mask = "00000000000";
			this.telMasterOsm2.Name = "telMasterOsm2";
			this.telMasterOsm2.PromptChar = ' ';
			this.telMasterOsm2.ReadOnly = true;
			this.telMasterOsm2.Size = new System.Drawing.Size(112, 20);
			this.telMasterOsm2.TabIndex = 5;
			this.telMasterOsm2.Click += new System.EventHandler(this.ClicOnTlfVield);
			// 
			// dolMasterOsm2
			// 
			this.dolMasterOsm2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dolMasterOsm2.Location = new System.Drawing.Point(214, 40);
			this.dolMasterOsm2.Name = "dolMasterOsm2";
			this.dolMasterOsm2.ReadOnly = true;
			this.dolMasterOsm2.Size = new System.Drawing.Size(157, 20);
			this.dolMasterOsm2.TabIndex = 4;
			// 
			// telMasterOsm1
			// 
			this.telMasterOsm1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.telMasterOsm1.Location = new System.Drawing.Point(377, 16);
			this.telMasterOsm1.Mask = "00000000000";
			this.telMasterOsm1.Name = "telMasterOsm1";
			this.telMasterOsm1.PromptChar = ' ';
			this.telMasterOsm1.ReadOnly = true;
			this.telMasterOsm1.Size = new System.Drawing.Size(112, 20);
			this.telMasterOsm1.TabIndex = 2;
			this.telMasterOsm1.Click += new System.EventHandler(this.ClicOnTlfVield);
			// 
			// cbMasterOsm4
			// 
			this.cbMasterOsm4.Dock = System.Windows.Forms.DockStyle.Top;
			this.cbMasterOsm4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbMasterOsm4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMasterOsm4.Location = new System.Drawing.Point(3, 88);
			this.cbMasterOsm4.Name = "cbMasterOsm4";
			this.cbMasterOsm4.Size = new System.Drawing.Size(205, 21);
			this.cbMasterOsm4.TabIndex = 9;
			this.cbMasterOsm4.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Combobox_DrawItem);
			this.cbMasterOsm4.SelectionChangeCommitted += new System.EventHandler(this.CbMasterOsm4_SelectionChangeCommitted);
			// 
			// cbMasterOsm3
			// 
			this.cbMasterOsm3.Dock = System.Windows.Forms.DockStyle.Top;
			this.cbMasterOsm3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbMasterOsm3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMasterOsm3.Location = new System.Drawing.Point(3, 64);
			this.cbMasterOsm3.Name = "cbMasterOsm3";
			this.cbMasterOsm3.Size = new System.Drawing.Size(205, 21);
			this.cbMasterOsm3.TabIndex = 6;
			this.cbMasterOsm3.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Combobox_DrawItem);
			this.cbMasterOsm3.SelectionChangeCommitted += new System.EventHandler(this.CbMasterOsm3_SelectionChangeCommitted);
			// 
			// cbMasterOsm2
			// 
			this.cbMasterOsm2.Dock = System.Windows.Forms.DockStyle.Top;
			this.cbMasterOsm2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbMasterOsm2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMasterOsm2.Location = new System.Drawing.Point(3, 40);
			this.cbMasterOsm2.Name = "cbMasterOsm2";
			this.cbMasterOsm2.Size = new System.Drawing.Size(205, 21);
			this.cbMasterOsm2.TabIndex = 3;
			this.cbMasterOsm2.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Combobox_DrawItem);
			this.cbMasterOsm2.SelectionChangeCommitted += new System.EventHandler(this.CbMasterOsm2_SelectionChangeCommitted);
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Dock = System.Windows.Forms.DockStyle.Top;
			this.label15.Location = new System.Drawing.Point(377, 0);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(112, 13);
			this.label15.TabIndex = 3;
			this.label15.Text = "Телефон";
			this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Dock = System.Windows.Forms.DockStyle.Top;
			this.label14.Location = new System.Drawing.Point(214, 0);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(157, 13);
			this.label14.TabIndex = 2;
			this.label14.Text = "Должность";
			this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// cbMasterOsm1
			// 
			this.cbMasterOsm1.Dock = System.Windows.Forms.DockStyle.Top;
			this.cbMasterOsm1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbMasterOsm1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMasterOsm1.Location = new System.Drawing.Point(3, 16);
			this.cbMasterOsm1.MaxDropDownItems = 24;
			this.cbMasterOsm1.Name = "cbMasterOsm1";
			this.cbMasterOsm1.Size = new System.Drawing.Size(205, 21);
			this.cbMasterOsm1.TabIndex = 0;
			this.cbMasterOsm1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Combobox_DrawItem);
			this.cbMasterOsm1.SelectionChangeCommitted += new System.EventHandler(this.CbMasterOsm1_SelectionChangeCommitted);
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Dock = System.Windows.Forms.DockStyle.Top;
			this.label13.Location = new System.Drawing.Point(3, 0);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(205, 13);
			this.label13.TabIndex = 1;
			this.label13.Text = "Руководитель бригады";
			this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// dolMasterOsm1
			// 
			this.dolMasterOsm1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dolMasterOsm1.Location = new System.Drawing.Point(214, 16);
			this.dolMasterOsm1.Name = "dolMasterOsm1";
			this.dolMasterOsm1.ReadOnly = true;
			this.dolMasterOsm1.Size = new System.Drawing.Size(157, 20);
			this.dolMasterOsm1.TabIndex = 1;
			// 
			// kol_pers_osm
			// 
			this.kol_pers_osm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.kol_pers_osm.Location = new System.Drawing.Point(132, 101);
			this.kol_pers_osm.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
			this.kol_pers_osm.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_pers_osm.Name = "kol_pers_osm";
			this.kol_pers_osm.Size = new System.Drawing.Size(53, 20);
			this.kol_pers_osm.TabIndex = 21;
			this.kol_pers_osm.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_pers_osm.ValueChanged += new System.EventHandler(this.Kol_pers_osm_ValueChanged);
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label12.Location = new System.Drawing.Point(8, 103);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(123, 13);
			this.label12.TabIndex = 20;
			this.label12.Text = "Количество персонала";
			// 
			// kol_br_osm
			// 
			this.kol_br_osm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.kol_br_osm.Location = new System.Drawing.Point(132, 68);
			this.kol_br_osm.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
			this.kol_br_osm.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_br_osm.Name = "kol_br_osm";
			this.kol_br_osm.Size = new System.Drawing.Size(53, 20);
			this.kol_br_osm.TabIndex = 19;
			this.kol_br_osm.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_br_osm.ValueChanged += new System.EventHandler(this.Kol_br_osm_ValueChanged);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label11.Location = new System.Drawing.Point(8, 70);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(104, 13);
			this.label11.TabIndex = 18;
			this.label11.Text = "Количество бригад";
			// 
			// t_osm
			// 
			this.t_osm.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_osm.Location = new System.Drawing.Point(94, 36);
			this.t_osm.Mask = "00:00";
			this.t_osm.Name = "t_osm";
			this.t_osm.PromptChar = ' ';
			this.t_osm.Size = new System.Drawing.Size(42, 18);
			this.t_osm.TabIndex = 17;
			this.t_osm.ValidatingType = typeof(System.DateTime);
			this.t_osm.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label10.Location = new System.Drawing.Point(9, 39);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(83, 13);
			this.label10.TabIndex = 16;
			this.label10.Text = "время допуска";
			// 
			// groupBox4
			// 
			this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(255)))), ((int)(((byte)(235)))));
			this.groupBox4.Controls.Add(this.button7);
			this.groupBox4.Controls.Add(this.cbBasaAvr);
			this.groupBox4.Controls.Add(this.label25);
			this.groupBox4.Controls.Add(this.t_plan_okon);
			this.groupBox4.Controls.Add(this.label29);
			this.groupBox4.Controls.Add(this.groupBox6);
			this.groupBox4.Controls.Add(this.cbPrinadl_br);
			this.groupBox4.Controls.Add(this.label22);
			this.groupBox4.Controls.Add(this.label21);
			this.groupBox4.Controls.Add(this.telMasterAvr);
			this.groupBox4.Controls.Add(this.dolMasterAvr);
			this.groupBox4.Controls.Add(this.cbMasterAvr);
			this.groupBox4.Controls.Add(this.kol_pers_avr);
			this.groupBox4.Controls.Add(this.label19);
			this.groupBox4.Controls.Add(this.kol_br_avr);
			this.groupBox4.Controls.Add(this.label20);
			this.groupBox4.Controls.Add(this.button5);
			this.groupBox4.Controls.Add(this.t_vkl_vl);
			this.groupBox4.Controls.Add(this.d_vkl_vl);
			this.groupBox4.Controls.Add(this.label18);
			this.groupBox4.Controls.Add(this.button4);
			this.groupBox4.Controls.Add(this.t_avr);
			this.groupBox4.Controls.Add(this.d_avr);
			this.groupBox4.Controls.Add(this.label17);
			this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox4.Location = new System.Drawing.Point(3, 317);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(713, 164);
			this.groupBox4.TabIndex = 2;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Проведение АВР";
			this.groupBox4.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// button7
			// 
			this.button7.ImageIndex = 0;
			this.button7.ImageList = this.imageList1;
			this.button7.Location = new System.Drawing.Point(456, 126);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(24, 20);
			this.button7.TabIndex = 46;
			this.Hint1.SetToolTip(this.button7, "Добавить нового руководителя бригады");
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.Button7_Click);
			// 
			// cbBasaAvr
			// 
			this.cbBasaAvr.DisplayMember = "0";
			this.cbBasaAvr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbBasaAvr.FormattingEnabled = true;
			this.cbBasaAvr.Location = new System.Drawing.Point(108, 60);
			this.cbBasaAvr.MaxLength = 255;
			this.cbBasaAvr.Name = "cbBasaAvr";
			this.cbBasaAvr.Size = new System.Drawing.Size(267, 21);
			this.cbBasaAvr.TabIndex = 5;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label25.Location = new System.Drawing.Point(2, 63);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(108, 13);
			this.label25.TabIndex = 45;
			this.label25.Text = "Место базирования";
			// 
			// t_plan_okon
			// 
			this.t_plan_okon.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_plan_okon.Location = new System.Drawing.Point(661, 140);
			this.t_plan_okon.Mask = "00:00";
			this.t_plan_okon.Name = "t_plan_okon";
			this.t_plan_okon.PromptChar = ' ';
			this.t_plan_okon.Size = new System.Drawing.Size(42, 18);
			this.t_plan_okon.TabIndex = 13;
			this.t_plan_okon.ValidatingType = typeof(System.DateTime);
			this.t_plan_okon.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label29.Location = new System.Drawing.Point(486, 143);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(170, 13);
			this.label29.TabIndex = 43;
			this.label29.Text = "Планируемое время окончания ";
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.Kran);
			this.groupBox6.Controls.Add(this.Label30);
			this.groupBox6.Controls.Add(this.BKM);
			this.groupBox6.Controls.Add(this.label24);
			this.groupBox6.Controls.Add(this.AGP);
			this.groupBox6.Controls.Add(this.label23);
			this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox6.Location = new System.Drawing.Point(498, 63);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(177, 78);
			this.groupBox6.TabIndex = 12;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Количество спецтехники";
			// 
			// Kran
			// 
			this.Kran.Location = new System.Drawing.Point(52, 56);
			this.Kran.Name = "Kran";
			this.Kran.Size = new System.Drawing.Size(117, 20);
			this.Kran.TabIndex = 5;
			// 
			// Label30
			// 
			this.Label30.AutoSize = true;
			this.Label30.Location = new System.Drawing.Point(15, 58);
			this.Label30.Name = "Label30";
			this.Label30.Size = new System.Drawing.Size(32, 13);
			this.Label30.TabIndex = 4;
			this.Label30.Text = "Кран";
			// 
			// BKM
			// 
			this.BKM.Location = new System.Drawing.Point(52, 35);
			this.BKM.Name = "BKM";
			this.BKM.Size = new System.Drawing.Size(117, 20);
			this.BKM.TabIndex = 3;
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(15, 37);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(30, 13);
			this.label24.TabIndex = 2;
			this.label24.Text = "БКМ";
			// 
			// AGP
			// 
			this.AGP.Location = new System.Drawing.Point(52, 14);
			this.AGP.Name = "AGP";
			this.AGP.Size = new System.Drawing.Size(117, 20);
			this.AGP.TabIndex = 0;
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(15, 16);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(28, 13);
			this.label23.TabIndex = 0;
			this.label23.Text = "АГП";
			// 
			// cbPrinadl_br
			// 
			this.cbPrinadl_br.DisplayMember = "0";
			this.cbPrinadl_br.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
			this.cbPrinadl_br.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbPrinadl_br.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbPrinadl_br.FormattingEnabled = true;
			this.cbPrinadl_br.Location = new System.Drawing.Point(132, 86);
			this.cbPrinadl_br.Name = "cbPrinadl_br";
			this.cbPrinadl_br.Size = new System.Drawing.Size(322, 21);
			this.cbPrinadl_br.TabIndex = 6;
			this.cbPrinadl_br.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.Combobox_DrawItem);
			this.cbPrinadl_br.SelectionChangeCommitted += new System.EventHandler(this.CbPrinadl_br_SelectionChangeCommitted);
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label22.Location = new System.Drawing.Point(2, 89);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(135, 13);
			this.label22.TabIndex = 40;
			this.label22.Text = "Принадлежность бригад ";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label21.Location = new System.Drawing.Point(8, 111);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(422, 13);
			this.label21.TabIndex = 39;
			this.label21.Text = "Руководитель бригады                                           Должность         " +
    "             Телефон";
			// 
			// telMasterAvr
			// 
			this.telMasterAvr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.telMasterAvr.Location = new System.Drawing.Point(360, 126);
			this.telMasterAvr.Mask = "00000000000";
			this.telMasterAvr.Name = "telMasterAvr";
			this.telMasterAvr.PromptChar = ' ';
			this.telMasterAvr.ReadOnly = true;
			this.telMasterAvr.Size = new System.Drawing.Size(94, 20);
			this.telMasterAvr.TabIndex = 9;
			this.telMasterAvr.Click += new System.EventHandler(this.ClicOnTlfVield);
			// 
			// dolMasterAvr
			// 
			this.dolMasterAvr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.dolMasterAvr.Location = new System.Drawing.Point(222, 125);
			this.dolMasterAvr.Name = "dolMasterAvr";
			this.dolMasterAvr.ReadOnly = true;
			this.dolMasterAvr.Size = new System.Drawing.Size(132, 20);
			this.dolMasterAvr.TabIndex = 8;
			// 
			// cbMasterAvr
			// 
			this.cbMasterAvr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbMasterAvr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbMasterAvr.Location = new System.Drawing.Point(10, 125);
			this.cbMasterAvr.Name = "cbMasterAvr";
			this.cbMasterAvr.Size = new System.Drawing.Size(198, 21);
			this.cbMasterAvr.TabIndex = 7;
			this.cbMasterAvr.SelectionChangeCommitted += new System.EventHandler(this.CbMasterAvr_SelectionChangeCommitted);
			// 
			// kol_pers_avr
			// 
			this.kol_pers_avr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.kol_pers_avr.Location = new System.Drawing.Point(626, 37);
			this.kol_pers_avr.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
			this.kol_pers_avr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_pers_avr.Name = "kol_pers_avr";
			this.kol_pers_avr.Size = new System.Drawing.Size(53, 20);
			this.kol_pers_avr.TabIndex = 11;
			this.kol_pers_avr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label19.Location = new System.Drawing.Point(502, 39);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(123, 13);
			this.label19.TabIndex = 34;
			this.label19.Text = "Количество персонала";
			// 
			// kol_br_avr
			// 
			this.kol_br_avr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.kol_br_avr.Location = new System.Drawing.Point(626, 12);
			this.kol_br_avr.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
			this.kol_br_avr.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.kol_br_avr.Name = "kol_br_avr";
			this.kol_br_avr.Size = new System.Drawing.Size(53, 20);
			this.kol_br_avr.TabIndex = 10;
			this.kol_br_avr.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label20.Location = new System.Drawing.Point(502, 14);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(104, 13);
			this.label20.TabIndex = 32;
			this.label20.Text = "Количество бригад";
			// 
			// button5
			// 
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.button5.Location = new System.Drawing.Point(311, 32);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(15, 20);
			this.button5.TabIndex = 31;
			this.button5.TabStop = false;
			this.button5.Text = "<";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.Button5_Click);
			// 
			// t_vkl_vl
			// 
			this.t_vkl_vl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_vkl_vl.Location = new System.Drawing.Point(266, 32);
			this.t_vkl_vl.Mask = "00:00";
			this.t_vkl_vl.Name = "t_vkl_vl";
			this.t_vkl_vl.PromptChar = ' ';
			this.t_vkl_vl.Size = new System.Drawing.Size(42, 18);
			this.t_vkl_vl.TabIndex = 4;
			this.t_vkl_vl.ValidatingType = typeof(System.DateTime);
			this.t_vkl_vl.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// d_vkl_vl
			// 
			this.d_vkl_vl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.d_vkl_vl.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.d_vkl_vl.Location = new System.Drawing.Point(168, 32);
			this.d_vkl_vl.Name = "d_vkl_vl";
			this.d_vkl_vl.Size = new System.Drawing.Size(92, 18);
			this.d_vkl_vl.TabIndex = 3;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label18.Location = new System.Drawing.Point(2, 35);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(163, 13);
			this.label18.TabIndex = 29;
			this.label18.Text = "Дата и время перезапитки ВЛ";
			// 
			// button4
			// 
			this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.button4.Location = new System.Drawing.Point(311, 11);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(15, 20);
			this.button4.TabIndex = 27;
			this.button4.TabStop = false;
			this.button4.Text = "<";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.Button4_Click);
			// 
			// t_avr
			// 
			this.t_avr.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_avr.Location = new System.Drawing.Point(266, 11);
			this.t_avr.Mask = "00:00";
			this.t_avr.Name = "t_avr";
			this.t_avr.PromptChar = ' ';
			this.t_avr.Size = new System.Drawing.Size(42, 18);
			this.t_avr.TabIndex = 2;
			this.t_avr.ValidatingType = typeof(System.DateTime);
			this.t_avr.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// d_avr
			// 
			this.d_avr.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.d_avr.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.d_avr.Location = new System.Drawing.Point(168, 11);
			this.d_avr.Name = "d_avr";
			this.d_avr.Size = new System.Drawing.Size(92, 18);
			this.d_avr.TabIndex = 1;
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label17.Location = new System.Drawing.Point(44, 15);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(121, 13);
			this.label17.TabIndex = 15;
			this.label17.Text = "Дата и время допуска";
			// 
			// groupBox5
			// 
			this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(255)))));
			this.groupBox5.Controls.Add(this.btnDotObemRabot);
			this.groupBox5.Controls.Add(this.cbEndOfWork);
			this.groupBox5.Controls.Add(this.btn_set_t_vkl_potr);
			this.groupBox5.Controls.Add(this.t_vkl_potr);
			this.groupBox5.Controls.Add(this.d_vkl_potr);
			this.groupBox5.Controls.Add(this.cbPerem_br);
			this.groupBox5.Controls.Add(this.label27);
			this.groupBox5.Controls.Add(this.obem_rabot);
			this.groupBox5.Controls.Add(this.label26);
			this.groupBox5.Controls.Add(this.label28);
			this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
			this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.groupBox5.Location = new System.Drawing.Point(3, 481);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(713, 90);
			this.groupBox5.TabIndex = 3;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Завершение работ";
			this.groupBox5.Paint += new System.Windows.Forms.PaintEventHandler(this.GroupBox1_Paint);
			// 
			// btnDotObemRabot
			// 
			this.btnDotObemRabot.Cursor = System.Windows.Forms.Cursors.PanWest;
			this.btnDotObemRabot.Enabled = false;
			this.btnDotObemRabot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.btnDotObemRabot.Location = new System.Drawing.Point(690, 62);
			this.btnDotObemRabot.Name = "btnDotObemRabot";
			this.btnDotObemRabot.Size = new System.Drawing.Size(16, 21);
			this.btnDotObemRabot.TabIndex = 47;
			this.btnDotObemRabot.Text = "Ш";
			this.btnDotObemRabot.UseVisualStyleBackColor = true;
			this.btnDotObemRabot.Click += new System.EventHandler(this.BtnDotObemRabot_Click);
			// 
			// cbEndOfWork
			// 
			this.cbEndOfWork.AutoSize = true;
			this.cbEndOfWork.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbEndOfWork.Location = new System.Drawing.Point(12, 19);
			this.cbEndOfWork.Name = "cbEndOfWork";
			this.cbEndOfWork.Size = new System.Drawing.Size(125, 17);
			this.cbEndOfWork.TabIndex = 0;
			this.cbEndOfWork.Text = "Работы завершены";
			this.cbEndOfWork.UseVisualStyleBackColor = true;
			this.cbEndOfWork.CheckedChanged += new System.EventHandler(this.CheckBox1_CheckedChanged);
			// 
			// btn_set_t_vkl_potr
			// 
			this.btn_set_t_vkl_potr.Enabled = false;
			this.btn_set_t_vkl_potr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.btn_set_t_vkl_potr.Location = new System.Drawing.Point(687, 19);
			this.btn_set_t_vkl_potr.Name = "btn_set_t_vkl_potr";
			this.btn_set_t_vkl_potr.Size = new System.Drawing.Size(15, 20);
			this.btn_set_t_vkl_potr.TabIndex = 46;
			this.btn_set_t_vkl_potr.TabStop = false;
			this.btn_set_t_vkl_potr.Text = "<";
			this.btn_set_t_vkl_potr.UseVisualStyleBackColor = true;
			this.btn_set_t_vkl_potr.Click += new System.EventHandler(this.Btn_set_t_vkl_potr_Click);
			// 
			// t_vkl_potr
			// 
			this.t_vkl_potr.Enabled = false;
			this.t_vkl_potr.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.t_vkl_potr.Location = new System.Drawing.Point(639, 19);
			this.t_vkl_potr.Mask = "00:00";
			this.t_vkl_potr.Name = "t_vkl_potr";
			this.t_vkl_potr.PromptChar = ' ';
			this.t_vkl_potr.Size = new System.Drawing.Size(42, 18);
			this.t_vkl_potr.TabIndex = 2;
			this.t_vkl_potr.ValidatingType = typeof(System.DateTime);
			this.t_vkl_potr.Click += new System.EventHandler(this.ClicOnTimeVield);
			// 
			// d_vkl_potr
			// 
			this.d_vkl_potr.Enabled = false;
			this.d_vkl_potr.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.d_vkl_potr.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.d_vkl_potr.Location = new System.Drawing.Point(541, 19);
			this.d_vkl_potr.Name = "d_vkl_potr";
			this.d_vkl_potr.Size = new System.Drawing.Size(92, 18);
			this.d_vkl_potr.TabIndex = 1;
			// 
			// cbPerem_br
			// 
			this.cbPerem_br.DisplayMember = "0";
			this.cbPerem_br.Enabled = false;
			this.cbPerem_br.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.cbPerem_br.FormattingEnabled = true;
			this.cbPerem_br.Location = new System.Drawing.Point(136, 41);
			this.cbPerem_br.Name = "cbPerem_br";
			this.cbPerem_br.Size = new System.Drawing.Size(377, 21);
			this.cbPerem_br.TabIndex = 3;
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label27.Location = new System.Drawing.Point(8, 44);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(126, 13);
			this.label27.TabIndex = 26;
			this.label27.Text = "Перемещение бригады";
			// 
			// obem_rabot
			// 
			this.obem_rabot.Enabled = false;
			this.obem_rabot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.obem_rabot.Location = new System.Drawing.Point(160, 63);
			this.obem_rabot.MaxLength = 255;
			this.obem_rabot.Name = "obem_rabot";
			this.obem_rabot.Size = new System.Drawing.Size(530, 20);
			this.obem_rabot.TabIndex = 4;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label26.Location = new System.Drawing.Point(8, 66);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(146, 13);
			this.label26.TabIndex = 0;
			this.label26.Text = "Объём выполненных работ";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.label28.Location = new System.Drawing.Point(387, 20);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(152, 13);
			this.label28.TabIndex = 45;
			this.label28.Text = "Дата / время включения ВЛ";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.cbUser);
			this.panel1.Controls.Add(this.label9);
			this.panel1.Controls.Add(this.btn_save);
			this.panel1.Controls.Add(this.button2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(3, 573);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(713, 36);
			this.panel1.TabIndex = 4;
			// 
			// cbUser
			// 
			this.cbUser.Enabled = false;
			this.cbUser.FormattingEnabled = true;
			this.cbUser.Location = new System.Drawing.Point(54, 7);
			this.cbUser.Name = "cbUser";
			this.cbUser.Size = new System.Drawing.Size(193, 21);
			this.cbUser.TabIndex = 11;
			this.cbUser.Text = "user";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(2, 10);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(47, 13);
			this.label9.TabIndex = 10;
			this.label9.Text = "Создал:";
			// 
			// btn_save
			// 
			this.btn_save.Location = new System.Drawing.Point(456, 3);
			this.btn_save.Name = "btn_save";
			this.btn_save.Size = new System.Drawing.Size(145, 29);
			this.btn_save.TabIndex = 8;
			this.btn_save.Text = "Сохранить и выйти";
			this.btn_save.UseVisualStyleBackColor = true;
			this.btn_save.Click += new System.EventHandler(this.Button1_Click);
			// 
			// button2
			// 
			this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button2.Location = new System.Drawing.Point(607, 2);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(99, 29);
			this.button2.TabIndex = 9;
			this.button2.Text = "Отмена";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// contextMenuResult_Osm
			// 
			this.contextMenuResult_Osm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
			this.contextMenuResult_Osm.Name = "contextMenuResult_Osm";
			this.contextMenuResult_Osm.ShowImageMargin = false;
			this.contextMenuResult_Osm.Size = new System.Drawing.Size(296, 180);
			this.contextMenuResult_Osm.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ContextMenuResult_Osm_ItemClicked);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem1.Text = "Обрыв провода в пролетах опор №";
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem2.Text = "Падение опоры №";
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			this.toolStripMenuItem3.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem3.Text = "Схлест проводов в пролетах опор №";
			// 
			// toolStripMenuItem4
			// 
			this.toolStripMenuItem4.Name = "toolStripMenuItem4";
			this.toolStripMenuItem4.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem4.Text = "Срыв изолятора на опоре №";
			// 
			// toolStripMenuItem5
			// 
			this.toolStripMenuItem5.Name = "toolStripMenuItem5";
			this.toolStripMenuItem5.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem5.Text = "Срыв вязки провода на опоре №";
			// 
			// toolStripMenuItem6
			// 
			this.toolStripMenuItem6.Name = "toolStripMenuItem6";
			this.toolStripMenuItem6.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem6.Text = "Срыв крюка на опоре №";
			// 
			// toolStripMenuItem7
			// 
			this.toolStripMenuItem7.Name = "toolStripMenuItem7";
			this.toolStripMenuItem7.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem7.Text = "Отключение автоматического выключателя";
			// 
			// toolStripMenuItem8
			// 
			this.toolStripMenuItem8.Name = "toolStripMenuItem8";
			this.toolStripMenuItem8.Size = new System.Drawing.Size(295, 22);
			this.toolStripMenuItem8.Text = "Размыкание контакта н/в вставки ПН-2 100А";
			// 
			// contextMenuObem_Rabot
			// 
			this.contextMenuObem_Rabot.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заменаПроводаВПролетахОпорToolStripMenuItem,
            this.заменаОпорыToolStripMenuItem,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14});
			this.contextMenuObem_Rabot.Name = "contextMenuStrip1";
			this.contextMenuObem_Rabot.ShowImageMargin = false;
			this.contextMenuObem_Rabot.Size = new System.Drawing.Size(289, 180);
			this.contextMenuObem_Rabot.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ContextMenuObem_Rabot_ItemClicked);
			// 
			// заменаПроводаВПролетахОпорToolStripMenuItem
			// 
			this.заменаПроводаВПролетахОпорToolStripMenuItem.Name = "заменаПроводаВПролетахОпорToolStripMenuItem";
			this.заменаПроводаВПролетахОпорToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
			this.заменаПроводаВПролетахОпорToolStripMenuItem.Text = "Замена провода в пролетах опор №";
			// 
			// заменаОпорыToolStripMenuItem
			// 
			this.заменаОпорыToolStripMenuItem.Name = "заменаОпорыToolStripMenuItem";
			this.заменаОпорыToolStripMenuItem.Size = new System.Drawing.Size(288, 22);
			this.заменаОпорыToolStripMenuItem.Text = "Замена опоры №";
			// 
			// toolStripMenuItem9
			// 
			this.toolStripMenuItem9.Name = "toolStripMenuItem9";
			this.toolStripMenuItem9.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem9.Text = "Перетяжка провода в пролетах опор №";
			// 
			// toolStripMenuItem10
			// 
			this.toolStripMenuItem10.Name = "toolStripMenuItem10";
			this.toolStripMenuItem10.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem10.Text = "Замена изолятора на опоре №";
			// 
			// toolStripMenuItem11
			// 
			this.toolStripMenuItem11.Name = "toolStripMenuItem11";
			this.toolStripMenuItem11.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem11.Text = "Замена вязки провода на опоре №";
			// 
			// toolStripMenuItem12
			// 
			this.toolStripMenuItem12.Name = "toolStripMenuItem12";
			this.toolStripMenuItem12.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem12.Text = "Замена крюка на опоре №";
			// 
			// toolStripMenuItem13
			// 
			this.toolStripMenuItem13.Name = "toolStripMenuItem13";
			this.toolStripMenuItem13.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem13.Text = "Включение автоматического выключателя";
			// 
			// toolStripMenuItem14
			// 
			this.toolStripMenuItem14.Name = "toolStripMenuItem14";
			this.toolStripMenuItem14.Size = new System.Drawing.Size(288, 22);
			this.toolStripMenuItem14.Text = "Замена н/в вставки ПН-2 100А";
			// 
			// Favr
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(719, 612);
			this.ControlBox = false;
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.groupBox5);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Name = "Favr";
			this.Padding = new System.Windows.Forms.Padding(3);
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Отключение";
			this.Shown += new System.EventHandler(this.Favr_Shown);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.P_rise)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_rise)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.P_load)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.TP)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SZO)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.Population)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NP)).EndInit();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.tableMastersOsm.ResumeLayout(false);
			this.tableMastersOsm.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.kol_pers_osm)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_br_osm)).EndInit();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.Kran)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BKM)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.AGP)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_pers_avr)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.kol_br_avr)).EndInit();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.contextMenuResult_Osm.ResumeLayout(false);
			this.contextMenuObem_Rabot.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.GroupBox groupBox4;
        public System.Windows.Forms.GroupBox groupBox5;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.MaskedTextBox t_otkl;
        public System.Windows.Forms.ComboBox cbFider;
        public System.Windows.Forms.DateTimePicker d_otkl;
        public System.Windows.Forms.ComboBox cbRes;
        public System.Windows.Forms.ComboBox cbCompany;
        public System.Windows.Forms.TableLayoutPanel tableMastersOsm;
        public System.Windows.Forms.ComboBox cbMasterOsm4;
        public System.Windows.Forms.ComboBox cbMasterOsm3;
        public System.Windows.Forms.ComboBox cbMasterOsm2;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.ComboBox cbMasterOsm1;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.MaskedTextBox t_osm;
        public System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button btn_save;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.ComboBox cbUser;
//        public System.Windows.Forms.TextBox telMasterOsm4;
        public System.Windows.Forms.MaskedTextBox telMasterOsm4;
        public System.Windows.Forms.TextBox dolMasterOsm4;
        public System.Windows.Forms.MaskedTextBox telMasterOsm3;
        public System.Windows.Forms.TextBox dolMasterOsm3;
        public System.Windows.Forms.MaskedTextBox telMasterOsm2;
        public System.Windows.Forms.TextBox dolMasterOsm2;
        public System.Windows.Forms.MaskedTextBox telMasterOsm1;
        public System.Windows.Forms.TextBox dolMasterOsm1;
        public System.Windows.Forms.TextBox result_osm;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.MaskedTextBox t_avr;
        public System.Windows.Forms.DateTimePicker d_avr;
        public System.Windows.Forms.Label label17;
        public System.Windows.Forms.Button button5;
        public System.Windows.Forms.MaskedTextBox t_vkl_vl;
        public System.Windows.Forms.Label label18;
        public System.Windows.Forms.DateTimePicker d_vkl_vl;
        public System.Windows.Forms.GroupBox groupBox6;
        public System.Windows.Forms.NumericUpDown Kran;
        public System.Windows.Forms.Label Label30;
        public System.Windows.Forms.NumericUpDown BKM;
        public System.Windows.Forms.Label label24;
        public System.Windows.Forms.NumericUpDown AGP;
        public System.Windows.Forms.Label label23;
        public System.Windows.Forms.ComboBox cbPrinadl_br;
        public System.Windows.Forms.Label label22;
        public System.Windows.Forms.Label label21;
        public System.Windows.Forms.MaskedTextBox telMasterAvr;
        public System.Windows.Forms.TextBox dolMasterAvr;
        public System.Windows.Forms.ComboBox cbMasterAvr;
        public System.Windows.Forms.NumericUpDown kol_pers_avr;
        public System.Windows.Forms.Label label19;
        public System.Windows.Forms.NumericUpDown kol_br_avr;
        public System.Windows.Forms.Label label20;
        public System.Windows.Forms.Button btn_set_t_vkl_potr;
        public System.Windows.Forms.MaskedTextBox t_vkl_potr;
        public System.Windows.Forms.DateTimePicker d_vkl_potr;
        public System.Windows.Forms.Label label28;
        public System.Windows.Forms.ComboBox cbPerem_br;
        public System.Windows.Forms.Label label27;
        public System.Windows.Forms.Label label26;
        public System.Windows.Forms.TextBox obem_rabot;
        public System.Windows.Forms.MaskedTextBox t_plan_okon;
        public System.Windows.Forms.Label label29;
        public System.Windows.Forms.CheckBox cbEndOfWork;
        public System.Windows.Forms.Label lbSelectRes;
        public System.Windows.Forms.Button button6;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.DateTimePicker d_osm;
        public System.Windows.Forms.NumericUpDown kol_br_osm;
        public System.Windows.Forms.NumericUpDown kol_pers_osm;
        public System.Windows.Forms.ComboBox cbBasaAvr;
        public System.Windows.Forms.Label label25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ContextMenuStrip contextMenuResult_Osm;
        private System.Windows.Forms.Button btnDotResultOsm;
        private System.Windows.Forms.ContextMenuStrip contextMenuObem_Rabot;
        private System.Windows.Forms.ToolStripMenuItem заменаПроводаВПролетахОпорToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заменаОпорыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.Button btnDotObemRabot;
        private System.Windows.Forms.ToolTip Hint1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button7;
        public System.Windows.Forms.Label lbFilter;
        public System.Windows.Forms.TextBox edFilter;
        private System.Windows.Forms.Label label31;
        public System.Windows.Forms.ComboBox cbTypeVL;
		private System.Windows.Forms.GroupBox groupBox7;
		public System.Windows.Forms.NumericUpDown P_rise;
		public System.Windows.Forms.NumericUpDown kol_rise;
		public System.Windows.Forms.Label label32;
		public System.Windows.Forms.Label label33;
		public System.Windows.Forms.GroupBox groupBox2;
		public System.Windows.Forms.Label label34;
		public System.Windows.Forms.NumericUpDown TP;
		public System.Windows.Forms.NumericUpDown SZO;
		public System.Windows.Forms.NumericUpDown Population;
		public System.Windows.Forms.NumericUpDown NP;
		public System.Windows.Forms.Label label7;
		public System.Windows.Forms.Label label8;
		public System.Windows.Forms.Label label6;
		public System.Windows.Forms.Label label5;
		public System.Windows.Forms.ComboBox cbP_load;
		public System.Windows.Forms.NumericUpDown P_load;
	}
}