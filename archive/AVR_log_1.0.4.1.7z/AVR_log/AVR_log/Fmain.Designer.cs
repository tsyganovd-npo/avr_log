﻿namespace AVR_log
{
    partial class Fmain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fmain));
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.OtklucheniyaMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.добавитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.удалитьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.редактироватьToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.экспортВExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.форма4ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.форма4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.форма15ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.SetupMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.OrganizationSetup = new System.Windows.Forms.ToolStripMenuItem();
			this.AddNewCompanyMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.AddNewResMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.AddNewPrinadlMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.UsersSetup = new System.Windows.Forms.ToolStripMenuItem();
			this.AddUserMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.ObjectSetup = new System.Windows.Forms.ToolStripMenuItem();
			this.AddFiderMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.EditFiderMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.DelFiderMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.ImportFidersMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MastersSetup = new System.Windows.Forms.ToolStripMenuItem();
			this.AddMasterMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.EditMasterMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.DelMasterMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.ImportMastersMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.DelAllComandMasters = new System.Windows.Forms.ToolStripMenuItem();
			this.PublicSetupMenu = new System.Windows.Forms.ToolStripMenuItem();
			this.AboutPrgToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnClearJournal = new System.Windows.Forms.Button();
			this.imageList1 = new System.Windows.Forms.ImageList(this.components);
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.StatusBar = new System.Windows.Forms.StatusStrip();
			this.StatusBarUserInfo = new System.Windows.Forms.ToolStripStatusLabel();
			this.StatusBarUpdateInfo = new System.Windows.Forms.ToolStripStatusLabel();
			this.StatusBarCountFiders = new System.Windows.Forms.ToolStripStatusLabel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.dgJournal = new System.Windows.Forms.DataGridView();
			this.JournalContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.редактироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.удалитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label1 = new System.Windows.Forms.Label();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			this.menuStrip1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.StatusBar.SuspendLayout();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgJournal)).BeginInit();
			this.JournalContextMenu.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OtklucheniyaMenuItem,
            this.экспортВExcelToolStripMenuItem,
            this.SetupMenu,
            this.AboutPrgToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// OtklucheniyaMenuItem
			// 
			this.OtklucheniyaMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.OtklucheniyaMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem1,
            this.удалитьToolStripMenuItem1,
            this.редактироватьToolStripMenuItem1});
			this.OtklucheniyaMenuItem.Name = "OtklucheniyaMenuItem";
			this.OtklucheniyaMenuItem.Size = new System.Drawing.Size(89, 20);
			this.OtklucheniyaMenuItem.Text = "Отключения";
			// 
			// добавитьToolStripMenuItem1
			// 
			this.добавитьToolStripMenuItem1.Name = "добавитьToolStripMenuItem1";
			this.добавитьToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
			this.добавитьToolStripMenuItem1.Text = "Добавить";
			this.добавитьToolStripMenuItem1.Click += new System.EventHandler(this.BtnAddNewAvr);
			// 
			// удалитьToolStripMenuItem1
			// 
			this.удалитьToolStripMenuItem1.Name = "удалитьToolStripMenuItem1";
			this.удалитьToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
			this.удалитьToolStripMenuItem1.Text = "Удалить";
			this.удалитьToolStripMenuItem1.Click += new System.EventHandler(this.BtnDeleteAvr);
			// 
			// редактироватьToolStripMenuItem1
			// 
			this.редактироватьToolStripMenuItem1.Name = "редактироватьToolStripMenuItem1";
			this.редактироватьToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
			this.редактироватьToolStripMenuItem1.Text = "Редактировать";
			this.редактироватьToolStripMenuItem1.Click += new System.EventHandler(this.BtnEditAvr);
			// 
			// экспортВExcelToolStripMenuItem
			// 
			this.экспортВExcelToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.экспортВExcelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.форма4ToolStripMenuItem1,
            this.форма4ToolStripMenuItem,
            this.форма15ToolStripMenuItem});
			this.экспортВExcelToolStripMenuItem.Name = "экспортВExcelToolStripMenuItem";
			this.экспортВExcelToolStripMenuItem.Size = new System.Drawing.Size(102, 20);
			this.экспортВExcelToolStripMenuItem.Text = "Экспорт в Excel";
			// 
			// форма4ToolStripMenuItem1
			// 
			this.форма4ToolStripMenuItem1.Name = "форма4ToolStripMenuItem1";
			this.форма4ToolStripMenuItem1.Size = new System.Drawing.Size(156, 22);
			this.форма4ToolStripMenuItem1.Text = "Форма 4 (2020)";
			this.форма4ToolStripMenuItem1.Click += new System.EventHandler(this.BtnExportJournal);
			// 
			// форма4ToolStripMenuItem
			// 
			this.форма4ToolStripMenuItem.Name = "форма4ToolStripMenuItem";
			this.форма4ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
			this.форма4ToolStripMenuItem.Text = "Форма 4 (2016)";
			this.форма4ToolStripMenuItem.Click += new System.EventHandler(this.BtnExportJournal);
			// 
			// форма15ToolStripMenuItem
			// 
			this.форма15ToolStripMenuItem.Name = "форма15ToolStripMenuItem";
			this.форма15ToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
			this.форма15ToolStripMenuItem.Text = "Форма 15";
			this.форма15ToolStripMenuItem.Click += new System.EventHandler(this.BtnExportJournal);
			// 
			// SetupMenu
			// 
			this.SetupMenu.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.SetupMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OrganizationSetup,
            this.UsersSetup,
            this.ObjectSetup,
            this.MastersSetup,
            this.PublicSetupMenu});
			this.SetupMenu.Name = "SetupMenu";
			this.SetupMenu.Size = new System.Drawing.Size(79, 20);
			this.SetupMenu.Text = "Настройки";
			// 
			// OrganizationSetup
			// 
			this.OrganizationSetup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddNewCompanyMenu,
            this.AddNewResMenu,
            this.AddNewPrinadlMenu});
			this.OrganizationSetup.Name = "OrganizationSetup";
			this.OrganizationSetup.Size = new System.Drawing.Size(203, 22);
			this.OrganizationSetup.Text = "Организации";
			// 
			// AddNewCompanyMenu
			// 
			this.AddNewCompanyMenu.Name = "AddNewCompanyMenu";
			this.AddNewCompanyMenu.Size = new System.Drawing.Size(172, 22);
			this.AddNewCompanyMenu.Text = "Добавить ПО";
			this.AddNewCompanyMenu.Click += new System.EventHandler(this.AddNewCompanyMenu_Click);
			// 
			// AddNewResMenu
			// 
			this.AddNewResMenu.Name = "AddNewResMenu";
			this.AddNewResMenu.Size = new System.Drawing.Size(172, 22);
			this.AddNewResMenu.Text = "Добавить РЭС";
			this.AddNewResMenu.Click += new System.EventHandler(this.AddNewResMenu_Click);
			// 
			// AddNewPrinadlMenu
			// 
			this.AddNewPrinadlMenu.Name = "AddNewPrinadlMenu";
			this.AddNewPrinadlMenu.Size = new System.Drawing.Size(172, 22);
			this.AddNewPrinadlMenu.Text = "Добавить филиал";
			this.AddNewPrinadlMenu.Click += new System.EventHandler(this.AddNewPrinadlMenu_Click);
			// 
			// UsersSetup
			// 
			this.UsersSetup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddUserMenu});
			this.UsersSetup.Name = "UsersSetup";
			this.UsersSetup.Size = new System.Drawing.Size(203, 22);
			this.UsersSetup.Text = "Пользователи";
			// 
			// AddUserMenu
			// 
			this.AddUserMenu.Name = "AddUserMenu";
			this.AddUserMenu.Size = new System.Drawing.Size(204, 22);
			this.AddUserMenu.Text = "Добавить пользователя";
			this.AddUserMenu.Click += new System.EventHandler(this.AddUserMenu_Click);
			// 
			// ObjectSetup
			// 
			this.ObjectSetup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddFiderMenu,
            this.EditFiderMenu,
            this.DelFiderMenu,
            this.ImportFidersMenuItem});
			this.ObjectSetup.Name = "ObjectSetup";
			this.ObjectSetup.Size = new System.Drawing.Size(203, 22);
			this.ObjectSetup.Text = "Объекты отключения";
			// 
			// AddFiderMenu
			// 
			this.AddFiderMenu.Name = "AddFiderMenu";
			this.AddFiderMenu.Size = new System.Drawing.Size(192, 22);
			this.AddFiderMenu.Text = "Добавить фидер";
			this.AddFiderMenu.Click += new System.EventHandler(this.AddFiderMenu_Click);
			// 
			// EditFiderMenu
			// 
			this.EditFiderMenu.Name = "EditFiderMenu";
			this.EditFiderMenu.Size = new System.Drawing.Size(192, 22);
			this.EditFiderMenu.Text = "Редактировать фидер";
			this.EditFiderMenu.Click += new System.EventHandler(this.EditFiderMenu_Click);
			// 
			// DelFiderMenu
			// 
			this.DelFiderMenu.Name = "DelFiderMenu";
			this.DelFiderMenu.Size = new System.Drawing.Size(192, 22);
			this.DelFiderMenu.Text = "Удалить фидер(ы)";
			this.DelFiderMenu.Click += new System.EventHandler(this.DelFiderMenu_Click);
			// 
			// ImportFidersMenuItem
			// 
			this.ImportFidersMenuItem.Name = "ImportFidersMenuItem";
			this.ImportFidersMenuItem.Size = new System.Drawing.Size(192, 22);
			this.ImportFidersMenuItem.Text = "Импорт из файла";
			this.ImportFidersMenuItem.Click += new System.EventHandler(this.ImportFidersMenuItem_Click);
			// 
			// MastersSetup
			// 
			this.MastersSetup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddMasterMenu,
            this.EditMasterMenu,
            this.DelMasterMenu,
            this.ImportMastersMenuItem,
            this.DelAllComandMasters});
			this.MastersSetup.Name = "MastersSetup";
			this.MastersSetup.Size = new System.Drawing.Size(203, 22);
			this.MastersSetup.Text = "Руководители бригад";
			// 
			// AddMasterMenu
			// 
			this.AddMasterMenu.Name = "AddMasterMenu";
			this.AddMasterMenu.Size = new System.Drawing.Size(308, 22);
			this.AddMasterMenu.Text = "Добавить руководителя бригады";
			this.AddMasterMenu.Click += new System.EventHandler(this.AddMasterMenu_Click);
			// 
			// EditMasterMenu
			// 
			this.EditMasterMenu.Name = "EditMasterMenu";
			this.EditMasterMenu.Size = new System.Drawing.Size(308, 22);
			this.EditMasterMenu.Text = "Редактировать руководителя бригады";
			this.EditMasterMenu.Click += new System.EventHandler(this.EditMasterMenu_Click);
			// 
			// DelMasterMenu
			// 
			this.DelMasterMenu.Name = "DelMasterMenu";
			this.DelMasterMenu.Size = new System.Drawing.Size(308, 22);
			this.DelMasterMenu.Text = "Убрать руководителя бригады";
			this.DelMasterMenu.Click += new System.EventHandler(this.DelMasterMenu_Click);
			// 
			// ImportMastersMenuItem
			// 
			this.ImportMastersMenuItem.Name = "ImportMastersMenuItem";
			this.ImportMastersMenuItem.Size = new System.Drawing.Size(308, 22);
			this.ImportMastersMenuItem.Text = "Импорт из файла";
			this.ImportMastersMenuItem.Click += new System.EventHandler(this.ImportMastersMenuItem_Click);
			// 
			// DelAllComandMasters
			// 
			this.DelAllComandMasters.Name = "DelAllComandMasters";
			this.DelAllComandMasters.Size = new System.Drawing.Size(308, 22);
			this.DelAllComandMasters.Text = "Удалить весь командированный персонал";
			this.DelAllComandMasters.Click += new System.EventHandler(this.DelAllComandMasters_Click);
			// 
			// PublicSetupMenu
			// 
			this.PublicSetupMenu.Name = "PublicSetupMenu";
			this.PublicSetupMenu.Size = new System.Drawing.Size(203, 22);
			this.PublicSetupMenu.Text = "Настройки программы";
			this.PublicSetupMenu.Click += new System.EventHandler(this.PublicSetupMenu_Click);
			// 
			// AboutPrgToolStripMenuItem
			// 
			this.AboutPrgToolStripMenuItem.Name = "AboutPrgToolStripMenuItem";
			this.AboutPrgToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
			this.AboutPrgToolStripMenuItem.Text = "О программе";
			this.AboutPrgToolStripMenuItem.Click += new System.EventHandler(this.AboutPrgToolStripMenuItem_Click);
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btnClearJournal);
			this.panel1.Controls.Add(this.button4);
			this.panel1.Controls.Add(this.button3);
			this.panel1.Controls.Add(this.button2);
			this.panel1.Controls.Add(this.button1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 24);
			this.panel1.Name = "panel1";
			this.panel1.Padding = new System.Windows.Forms.Padding(5);
			this.panel1.Size = new System.Drawing.Size(1008, 37);
			this.panel1.TabIndex = 1;
			// 
			// btnClearJournal
			// 
			this.btnClearJournal.AutoSize = true;
			this.btnClearJournal.Dock = System.Windows.Forms.DockStyle.Right;
			this.btnClearJournal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnClearJournal.ImageIndex = 4;
			this.btnClearJournal.ImageList = this.imageList1;
			this.btnClearJournal.Location = new System.Drawing.Point(806, 5);
			this.btnClearJournal.Name = "btnClearJournal";
			this.btnClearJournal.Size = new System.Drawing.Size(197, 27);
			this.btnClearJournal.TabIndex = 4;
			this.btnClearJournal.Text = "Удалить из журнала все записи";
			this.btnClearJournal.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.btnClearJournal.UseVisualStyleBackColor = true;
			this.btnClearJournal.Visible = false;
			this.btnClearJournal.Click += new System.EventHandler(this.BtnClearJournal_Click);
			// 
			// imageList1
			// 
			this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
			this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
			this.imageList1.Images.SetKeyName(0, "ic_add_circle_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(1, "ic_remove_circle_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(2, "ic_create_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(3, "ic_grid_on_grey600_18dp.png");
			this.imageList1.Images.SetKeyName(4, "ic_highlight_remove_grey600_18dp.png");
			// 
			// button4
			// 
			this.button4.AutoSize = true;
			this.button4.Dock = System.Windows.Forms.DockStyle.Left;
			this.button4.ImageIndex = 3;
			this.button4.ImageList = this.imageList1;
			this.button4.Location = new System.Drawing.Point(496, 5);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(116, 27);
			this.button4.TabIndex = 3;
			this.button4.Text = "Экспорт в Excel";
			this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.BtnExportJournal);
			// 
			// button3
			// 
			this.button3.AutoSize = true;
			this.button3.Dock = System.Windows.Forms.DockStyle.Left;
			this.button3.ImageIndex = 1;
			this.button3.ImageList = this.imageList1;
			this.button3.Location = new System.Drawing.Point(324, 5);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(172, 27);
			this.button3.TabIndex = 2;
			this.button3.Text = "Удалить отключение";
			this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.BtnDeleteAvr);
			// 
			// button2
			// 
			this.button2.AutoSize = true;
			this.button2.Dock = System.Windows.Forms.DockStyle.Left;
			this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button2.ImageIndex = 2;
			this.button2.ImageList = this.imageList1;
			this.button2.Location = new System.Drawing.Point(151, 5);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(173, 27);
			this.button2.TabIndex = 1;
			this.button2.Text = "Редактировать отключение";
			this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.BtnEditAvr);
			// 
			// button1
			// 
			this.button1.AutoSize = true;
			this.button1.Dock = System.Windows.Forms.DockStyle.Left;
			this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.ImageIndex = 0;
			this.button1.ImageList = this.imageList1;
			this.button1.Location = new System.Drawing.Point(5, 5);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(146, 27);
			this.button1.TabIndex = 0;
			this.button1.Text = "Добавить отключение";
			this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.BtnAddNewAvr);
			// 
			// StatusBar
			// 
			this.StatusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusBarUserInfo,
            this.StatusBarUpdateInfo,
            this.StatusBarCountFiders});
			this.StatusBar.Location = new System.Drawing.Point(0, 517);
			this.StatusBar.Name = "StatusBar";
			this.StatusBar.Size = new System.Drawing.Size(1008, 22);
			this.StatusBar.TabIndex = 2;
			this.StatusBar.Text = "statusStrip1";
			// 
			// StatusBarUserInfo
			// 
			this.StatusBarUserInfo.AutoSize = false;
			this.StatusBarUserInfo.Name = "StatusBarUserInfo";
			this.StatusBarUserInfo.Size = new System.Drawing.Size(250, 17);
			this.StatusBarUserInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// StatusBarUpdateInfo
			// 
			this.StatusBarUpdateInfo.Name = "StatusBarUpdateInfo";
			this.StatusBarUpdateInfo.Size = new System.Drawing.Size(12, 17);
			this.StatusBarUpdateInfo.Text = "-";
			// 
			// StatusBarCountFiders
			// 
			this.StatusBarCountFiders.Name = "StatusBarCountFiders";
			this.StatusBarCountFiders.Size = new System.Drawing.Size(731, 17);
			this.StatusBarCountFiders.Spring = true;
			this.StatusBarCountFiders.Text = " ";
			this.StatusBarCountFiders.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.dgJournal);
			this.panel2.Controls.Add(this.label1);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(0, 61);
			this.panel2.Name = "panel2";
			this.panel2.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
			this.panel2.Size = new System.Drawing.Size(1008, 456);
			this.panel2.TabIndex = 3;
			// 
			// dgJournal
			// 
			this.dgJournal.AllowUserToAddRows = false;
			this.dgJournal.AllowUserToDeleteRows = false;
			this.dgJournal.AllowUserToResizeRows = false;
			this.dgJournal.BackgroundColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgJournal.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
			this.dgJournal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgJournal.ContextMenuStrip = this.JournalContextMenu;
			dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
			this.dgJournal.DefaultCellStyle = dataGridViewCellStyle2;
			this.dgJournal.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgJournal.EnableHeadersVisualStyles = false;
			this.dgJournal.Location = new System.Drawing.Point(5, 0);
			this.dgJournal.MultiSelect = false;
			this.dgJournal.Name = "dgJournal";
			this.dgJournal.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
			dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
			this.dgJournal.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.dgJournal.RowHeadersVisible = false;
			this.dgJournal.RowHeadersWidth = 24;
			this.dgJournal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgJournal.ShowCellErrors = false;
			this.dgJournal.ShowCellToolTips = false;
			this.dgJournal.ShowEditingIcon = false;
			this.dgJournal.ShowRowErrors = false;
			this.dgJournal.Size = new System.Drawing.Size(998, 456);
			this.dgJournal.TabIndex = 4;
			this.dgJournal.Visible = false;
			this.dgJournal.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DgJournal_RowPostPaint);
			this.dgJournal.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.DgJournal_RowPrePaint);
			this.dgJournal.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DgJournal_MouseDown);
			// 
			// JournalContextMenu
			// 
			this.JournalContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьToolStripMenuItem,
            this.редактироватьToolStripMenuItem,
            this.удалитьToolStripMenuItem});
			this.JournalContextMenu.Name = "contextMenuStrip1";
			this.JournalContextMenu.ShowImageMargin = false;
			this.JournalContextMenu.Size = new System.Drawing.Size(130, 70);
			// 
			// добавитьToolStripMenuItem
			// 
			this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
			this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
			this.добавитьToolStripMenuItem.Text = "Добавить";
			this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.BtnAddNewAvr);
			// 
			// редактироватьToolStripMenuItem
			// 
			this.редактироватьToolStripMenuItem.Name = "редактироватьToolStripMenuItem";
			this.редактироватьToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
			this.редактироватьToolStripMenuItem.Text = "Редактировать";
			this.редактироватьToolStripMenuItem.Click += new System.EventHandler(this.BtnEditAvr);
			// 
			// удалитьToolStripMenuItem
			// 
			this.удалитьToolStripMenuItem.Name = "удалитьToolStripMenuItem";
			this.удалитьToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
			this.удалитьToolStripMenuItem.Text = "Удалить";
			this.удалитьToolStripMenuItem.Click += new System.EventHandler(this.BtnDeleteAvr);
			// 
			// label1
			// 
			this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label1.Location = new System.Drawing.Point(5, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(998, 456);
			this.label1.TabIndex = 0;
			this.label1.Text = "Журнал пустой.";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// timer1
			// 
			this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
			// 
			// Fmain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1008, 539);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.StatusBar);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.menuStrip1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "Fmain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Журнал АВР";
			this.Shown += new System.EventHandler(this.Fmain_Shown);
			this.Resize += new System.EventHandler(this.Fmain_Resize);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.StatusBar.ResumeLayout(false);
			this.StatusBar.PerformLayout();
			this.panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgJournal)).EndInit();
			this.JournalContextMenu.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.StatusStrip StatusBar;
        private System.Windows.Forms.ToolStripStatusLabel StatusBarUserInfo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgJournal;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ContextMenuStrip JournalContextMenu;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OtklucheniyaMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem удалитьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem редактироватьToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem экспортВExcelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форма4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem форма15ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OrganizationSetup;
        private System.Windows.Forms.ToolStripMenuItem UsersSetup;
        private System.Windows.Forms.ToolStripMenuItem ObjectSetup;
        private System.Windows.Forms.ToolStripMenuItem MastersSetup;
        private System.Windows.Forms.ToolStripMenuItem AddNewCompanyMenu;
        private System.Windows.Forms.ToolStripMenuItem AddNewResMenu;
        private System.Windows.Forms.ToolStripMenuItem AddUserMenu;
        private System.Windows.Forms.ToolStripMenuItem AddFiderMenu;
        private System.Windows.Forms.ToolStripMenuItem DelFiderMenu;
        public System.Windows.Forms.ToolStripMenuItem SetupMenu;
        private System.Windows.Forms.ToolStripMenuItem DelMasterMenu;
        private System.Windows.Forms.ToolStripMenuItem EditFiderMenu;
        private System.Windows.Forms.ToolStripMenuItem PublicSetupMenu;
        public System.Windows.Forms.ToolStripStatusLabel StatusBarUpdateInfo;
        public System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem EditMasterMenu;
        private System.Windows.Forms.ToolStripMenuItem AboutPrgToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel StatusBarCountFiders;
        private System.Windows.Forms.ToolStripMenuItem ImportFidersMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ImportMastersMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddNewPrinadlMenu;
        public System.Windows.Forms.ToolStripMenuItem AddMasterMenu;
        private System.Windows.Forms.Button btnClearJournal;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripMenuItem DelAllComandMasters;
		private System.Windows.Forms.ToolStripMenuItem форма4ToolStripMenuItem1;
	}
}

